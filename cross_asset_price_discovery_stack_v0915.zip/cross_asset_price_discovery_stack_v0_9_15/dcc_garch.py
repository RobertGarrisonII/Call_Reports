"""
dcc_garch.py
============
DCC-GARCH-X estimation in pure numpy/scipy (no arch/statsmodels). Models the
time-varying conditional correlation between SPY and ES so "comovement is strong
in volatile periods" becomes an estimated rho_t object rather than a coarse
volatile/benchmark split. The "-X" enters the univariate variance equations:

  GARCH(1,1)-X:  h_t = omega + alpha*eps_{t-1}^2 + beta*h_{t-1} + gamma'*X_{t-1}
  DCC(1,1):      Q_t = (1-a-b)*Qbar + a*z_{t-1}z_{t-1}' + b*Q_{t-1},
                 R_t = diag(Q_t)^{-1/2} Q_t diag(Q_t)^{-1/2}

X can be realized vol, |OFI|, the relative-depth state, etc. (predetermined).
Two-step Engle (2002) estimator: fit each marginal, standardize, fit DCC.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import minimize

EPS = 1e-10


# ── univariate GARCH(1,1)-X ──────────────────────────────────────────────────
def _garch_filter(eps, omega, alpha, beta, gamma, X):
    T = len(eps); h = np.empty(T)
    v = np.var(eps); h[0] = (v + EPS) if (np.isfinite(v) and v > 0) else EPS
    xg = np.zeros(T) if X is None else (X @ np.atleast_1d(gamma))
    for t in range(1, T):
        h[t] = omega + alpha * eps[t - 1] ** 2 + beta * h[t - 1] + xg[t - 1]
        if not (h[t] > EPS):                                 # NaN-safe floor (nan > EPS is False)
            h[t] = EPS
    return h

def garch_x_fit(eps, X=None):
    """Fit GARCH(1,1)-X by Gaussian MLE. eps: mean-zero series. X: T x p or None.
    Returns params dict, conditional variance h, standardized resid z."""
    eps = np.asarray(eps, float)
    Xm = None if X is None else (np.asarray(X, float).reshape(-1, 1)
                                 if np.asarray(X).ndim == 1 else np.asarray(X, float))
    fin = np.isfinite(eps) & (np.all(np.isfinite(Xm), axis=1) if Xm is not None else True)
    eps = eps[fin]; Xm = None if Xm is None else Xm[fin]
    v = np.var(eps)
    p = 0 if Xm is None else Xm.shape[1]

    def nll(theta):
        omega, alpha, beta = theta[0], theta[1], theta[2]
        gamma = theta[3:] if p else 0.0
        h = _garch_filter(eps, omega, alpha, beta, gamma, Xm)
        if not np.all(np.isfinite(h)) or np.any(h <= 0):
            return 1e10
        val = 0.5 * np.sum(np.log(2 * np.pi) + np.log(h) + eps ** 2 / h)
        return val if np.isfinite(val) else 1e10

    x0 = [0.1 * v, 0.05, 0.90] + [0.0] * p
    bounds = [(1e-9, 10 * v + 1e-6), (0.0, 0.5), (0.0, 0.999)] + [(-10 * v, 10 * v)] * p
    best = None
    for b0 in (0.90, 0.80, 0.50):
        x0[2] = b0
        r = minimize(nll, x0, method="L-BFGS-B", bounds=bounds)
        if best is None or r.fun < best.fun:
            best = r
    th = best.x
    gamma = th[3:] if p else np.array([])
    h = _garch_filter(eps, th[0], th[1], th[2], (gamma if p else 0.0), Xm)
    return {"omega": th[0], "alpha": th[1], "beta": th[2], "gamma": gamma,
            "loglik": -best.fun, "h": h, "z": eps / np.sqrt(h)}


# ── DCC(1,1) second stage ────────────────────────────────────────────────────
def _dcc_filter(Z, a, b):
    T, k = Z.shape
    Qbar = (Z.T @ Z) / T
    Q = Qbar.copy(); R = np.empty((T, k, k))
    for t in range(T):
        d = np.sqrt(np.maximum(np.diag(Q), EPS))
        Rt = np.clip(Q / np.outer(d, d), -1.0, 1.0)
        np.fill_diagonal(Rt, 1.0); R[t] = Rt
        if t < T - 1:
            zz = np.outer(Z[t], Z[t])
            Q = (1 - a - b) * Qbar + a * zz + b * Q
    return R

def dcc_fit(Z):
    """Engle DCC(1,1) on standardized residuals Z (T x k). Returns (a,b) and R_t."""
    T, k = Z.shape

    def nll(theta):
        a, b = theta
        if a < 0 or b < 0 or a + b >= 0.9999:
            return 1e10
        R = _dcc_filter(Z, a, b)
        ll = 0.0
        for t in range(T):
            Rt = R[t]
            sign, logdet = np.linalg.slogdet(Rt)
            if not (sign > 0) or not np.isfinite(logdet):     # NaN-safe (nan<=0 is False)
                return 1e10
            try:
                q = Z[t] @ np.linalg.solve(Rt, Z[t])
            except np.linalg.LinAlgError:
                return 1e10
            ll += logdet + q - Z[t] @ Z[t]
        return 0.5 * ll if np.isfinite(ll) else 1e10

    best = None
    for a0, b0 in ((0.02, 0.96), (0.05, 0.90), (0.10, 0.80)):
        r = minimize(nll, [a0, b0], method="Nelder-Mead",
                     options={"xatol": 1e-5, "fatol": 1e-5, "maxiter": 500})
        if best is None or r.fun < best.fun:
            best = r
    a, b = best.x
    if (not np.isfinite(best.fun)) or a < 0 or b < 0 or a + b >= 1.0:
        a, b = 0.0, 0.0                                       # fall back to constant (Qbar) correlation
    return {"a": a, "b": b, "R": _dcc_filter(Z, a, b), "loglik": -best.fun}


# ── Aielli (2013) corrected cDCC ──────────────────────────────────────────────
# Engle's DCC targets Qbar = E[z z'] but the recursion's invariant is NOT Qbar, so correlation
# targeting via Z'Z/T is INCONSISTENT (Aielli 2013, JBES). The cDCC fix rescales the news term by
# the conditional scale implied by Q_t -- z*_t = diag(Q_t)^{1/2} z_t -- so that E[z*_t z*_t']=S
# holds exactly and S is consistently estimable. This is the variant a tier-1 referee expects for
# a DCC dependence model; it also supplies the correlation path the copula layer conditions on.

def _cdcc_filter(Z, a, b, S):
    """cDCC recursion Q_t=(1-a-b)S + a z*_{t-1}z*_{t-1}' + b Q_{t-1}, z*_t=diag(Q_t)^{1/2} z_t.
    Returns the correlation path R_t and the rescaled residuals z*_t (for consistent targeting)."""
    T, k = Z.shape
    Q = S.copy(); R = np.empty((T, k, k)); Zstar = np.empty_like(Z)
    for t in range(T):
        d = np.sqrt(np.maximum(np.diag(Q), EPS))
        Rt = np.clip(Q / np.outer(d, d), -1.0, 1.0); np.fill_diagonal(Rt, 1.0); R[t] = Rt
        zstar = d * Z[t]                                       # diag(Q_t)^{1/2} ⊙ z_t
        Zstar[t] = zstar
        if t < T - 1:
            Q = (1 - a - b) * S + a * np.outer(zstar, zstar) + b * Q
    return R, Zstar


def _cdcc_target(Z, a, b, iters=8):
    """Aielli's consistent correlation-targeting estimator of S: the fixed point of
    S = (1/T) Σ z*_t z*_t' (z*_t depends on Q_t depends on S), iterated to convergence."""
    T = len(Z); S = (Z.T @ Z) / T
    for _ in range(iters):
        _, Zstar = _cdcc_filter(Z, a, b, S)
        S = (Zstar.T @ Zstar) / T
    return S


def _cdcc_nll(Z, a, b, S):
    R, _ = _cdcc_filter(Z, a, b, S); ll = 0.0
    for t in range(len(Z)):
        Rt = R[t]; sign, logdet = np.linalg.slogdet(Rt)
        if not (sign > 0) or not np.isfinite(logdet):
            return 1e10
        try:
            q = Z[t] @ np.linalg.solve(Rt, Z[t])
        except np.linalg.LinAlgError:
            return 1e10
        ll += logdet + q - Z[t] @ Z[t]
    return 0.5 * ll if np.isfinite(ll) else 1e10


def cdcc_fit(Z, target_iters=8):
    """Aielli (2013) cDCC(1,1) on standardized residuals Z (T x k). Consistent two-step: target S
    by the fixed-point estimator, MLE (a,b) with S held, then re-target at the fitted (a,b) and
    refit once. Returns (a, b), the consistent targeting matrix S, the correlation path R_t, loglik."""
    S = _cdcc_target(Z, 0.04, 0.92, iters=target_iters)        # pilot targeting

    def fit_ab(S_):
        def nll(theta):
            a, b = theta
            if a < 0 or b < 0 or a + b >= 0.9999:
                return 1e10
            return _cdcc_nll(Z, a, b, S_)
        best = None
        for a0, b0 in ((0.03, 0.95), (0.06, 0.90), (0.10, 0.80)):
            r = minimize(nll, [a0, b0], method="Nelder-Mead",
                         options={"xatol": 1e-5, "fatol": 1e-5, "maxiter": 400})
            if best is None or r.fun < best.fun:
                best = r
        return best

    best = fit_ab(S); a, b = best.x
    if np.isfinite(best.fun) and a >= 0 and b >= 0 and a + b < 1.0:
        S = _cdcc_target(Z, a, b, iters=target_iters)          # refine targeting at the fitted (a,b)
        best = fit_ab(S); a, b = best.x
    if (not np.isfinite(best.fun)) or a < 0 or b < 0 or a + b >= 1.0:
        a, b = 0.0, 0.0
    R, _ = _cdcc_filter(Z, a, b, S)
    return {"a": a, "b": b, "S": S, "R": R, "loglik": -best.fun}


# ── orchestrator ─────────────────────────────────────────────────────────────
def dcc_garch_x(returns, X=None, names=("SPY", "ES"), X_per_asset=None, dcc_method="cdcc"):
    """returns: T x 2 (SPY, ES). X: optional exogenous variance regressors shared by both
    marginals (1d/2d) or None. X_per_asset: optional list of one regressor block per column
    (so each asset's variance loads on its OWN liquidity); overrides X when given. ``dcc_method``
    selects the second-stage correlation recursion: ``"cdcc"`` (default, Aielli 2013 corrected,
    consistent targeting) or ``"engle"`` (the original DCC). Returns time-varying correlation
    rho_t, conditional vols, and stage parameters. Non-finite rows are dropped jointly (so the
    standardized residuals stay aligned); with too little clean data it returns NaNs rather than
    raising."""
    R = np.asarray(returns, float)
    k = R.shape[1]

    def _prep(x):
        if x is None:
            return None
        x = np.asarray(x, float)
        return x.reshape(-1, 1) if x.ndim == 1 else x

    if X_per_asset is not None:
        Xs = [_prep(x) for x in X_per_asset]
        if len(Xs) != k:
            raise ValueError("X_per_asset must have one entry per return column")
    else:
        Xs = [_prep(X)] * k
    fin = np.all(np.isfinite(R), axis=1)
    for x in Xs:
        if x is not None:
            fin = fin & np.all(np.isfinite(x), axis=1)
    R = R[fin]
    Xs = [None if x is None else x[fin] for x in Xs]
    if R.shape[0] < 50:                                      # not enough clean data to fit
        T0 = np.asarray(returns).shape[0]
        return {"rho": np.full(T0, np.nan), "cond_vol": np.full((T0, 2), np.nan),
                "marginals": {}, "dcc_a": np.nan, "dcc_b": np.nan, "R": None,
                "note": "insufficient finite data"}
    eps = R - R.mean(0)
    marg = [garch_x_fit(eps[:, j], Xs[j]) for j in range(R.shape[1])]
    Z = np.column_stack([m["z"] for m in marg])
    dcc = (cdcc_fit if dcc_method == "cdcc" else dcc_fit)(Z)
    rho = dcc["R"][:, 0, 1]
    return {"rho": rho, "cond_vol": np.column_stack([np.sqrt(m["h"]) for m in marg]),
            "marginals": dict(zip(names, marg)), "dcc_a": dcc["a"], "dcc_b": dcc["b"],
            "dcc_method": dcc_method, "R": dcc["R"]}


def _selftest():
    rng = np.random.default_rng(11)
    n = 6000
    # 1) DGP: true DCC correlation path + GARCH vols
    ta, tb = 0.04, 0.93; Qbar = np.array([[1.0, 0.5], [0.5, 1.0]])
    Q = Qbar.copy(); z = np.empty((n, 2)); rho_true = np.empty(n)
    for t in range(n):
        d = np.sqrt(np.diag(Q)); Rt = Q / np.outer(d, d); rho_true[t] = Rt[0, 1]
        z[t] = np.linalg.cholesky(Rt) @ rng.normal(size=2)
        Q = (1 - ta - tb) * Qbar + ta * np.outer(z[t], z[t]) + tb * Q
    eps = np.empty((n, 2)); h = np.full(2, 1.0)
    e = np.empty((n, 2))
    for j in range(2):
        hh = 1.0
        for t in range(n):
            if t > 0:
                hh = 0.02 + 0.08 * e[t - 1, j] ** 2 + 0.90 * hh
            e[t, j] = np.sqrt(hh) * z[t, j]
    out = dcc_garch_x(e)
    corr_path = np.corrcoef(out["rho"][50:], rho_true[50:])[0, 1]
    print("DCC-GARCH fit:")
    print("  dcc a=%.3f b=%.3f (true 0.04/0.93), a+b=%.3f" % (out["dcc_a"], out["dcc_b"], out["dcc_a"] + out["dcc_b"]))
    print("  GARCH SPY: alpha=%.3f beta=%.3f (true 0.08/0.90)"
          % (out["marginals"]["SPY"]["alpha"], out["marginals"]["SPY"]["beta"]))
    print("  corr(estimated rho_t, true rho_t) = %.3f" % corr_path)
    print("  checks: a+b<1:", out["dcc_a"] + out["dcc_b"] < 1,
          "| rho tracks truth:", corr_path > 0.6)

    # 2) GARCH-X: exogenous covariate genuinely raising variance -> gamma>0
    x = np.abs(rng.normal(0, 1, n))                      # predetermined vol covariate
    eg = np.empty(n); hh = 1.0
    for t in range(n):
        if t > 0:
            hh = 0.02 + 0.05 * eg[t - 1] ** 2 + 0.85 * hh + 0.30 * x[t - 1]
        eg[t] = np.sqrt(hh) * rng.normal()
    fx = garch_x_fit(eg, X=x)
    print("\nGARCH-X covariate recovery:")
    print("  gamma=%.3f (true 0.30), sign correct & positive:" % fx["gamma"][0], fx["gamma"][0] > 0.1)

    # 3) non-finite robustness: NaN/inf return segments must not poison the DCC fit.
    rr = rng.normal(0, 0.01, (1500, 2)); rr[300:320, 0] = np.nan; rr[900, 1] = np.inf
    rn = dcc_garch_x(rr)
    print("\nnon-finite robustness:")
    print("  dcc a+b<1 under NaN/inf returns:", bool(rn["dcc_a"] + rn["dcc_b"] < 1.0),
          "| mean rho finite:", bool(np.isfinite(np.nanmean(rn["rho"]))))

if __name__ == "__main__":
    _selftest()
