Generated output
================

All persisted output is written here by the driver, run_analysis.py. Each run
creates one self-contained folder:

  output/run_<timestamp>/
    final_dataset.parquet        the consolidated dataset that was analysed --
       (or final_dataset.csv.gz)  all sessions stacked, with leading
                                  session_date / regime / timestamp columns.
                                  parquet if pyarrow/fastparquet is installed,
                                  otherwise a single gzip-compressed CSV.
    tables/                      one CSV per analysis output (information shares,
                                  liquidity-conditional shares for the depth and
                                  FPCA states, the windowed panel + regression,
                                  cross-impact, IRF/FEVD, robustness, ...).
    report.md                   readable summary with the headline numbers.
    summary.json                the headline scalars + per-stage run status.
    analysis_objects.pkl        ONLY if --save-objects is passed (full Python
                                  objects for programmatic reload).

market_analysis_fixed.py writes nothing on its own -- it returns the per-session
frames in memory. To produce the artifacts above from a fresh extraction:

    python run_analysis.py --source extract            # MIDAS / Athena
    python run_analysis.py --source load --pickle ...  # from a saved pickle
    python run_analysis.py --source demo --quick       # synthetic smoke test

Code can reference this directory as:

    from cross_asset_price_discovery_stack import OUTPUT_DIR

The .gitkeep file preserves this otherwise-empty directory; the run_<timestamp>/
folders are intended to be git-ignored.
